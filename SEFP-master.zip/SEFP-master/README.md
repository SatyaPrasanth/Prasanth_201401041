# SEFP
This is the core directory structure (assignments, projects, feedback and more) of SEFP course at IIIT-Sri City, http://researchweb.iiit.ac.in/~sridhar_ch/courses/sefp/home.html

Everybody, clone this project structure in your accounts and start doing updates. 
Don't wait till you finish entire thing. Upload as-is
